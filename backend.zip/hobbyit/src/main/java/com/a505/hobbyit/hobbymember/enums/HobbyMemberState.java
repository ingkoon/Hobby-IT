package com.a505.hobbyit.hobbymember.enums;

public enum HobbyMemberState {
    ACTIVE, RESIGNED, KICKED
}
