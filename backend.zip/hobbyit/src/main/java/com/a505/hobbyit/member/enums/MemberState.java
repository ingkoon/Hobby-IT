package com.a505.hobbyit.member.enums;

public enum MemberState {
    BAN, ACTIVE, RESIGNED, WAITING
}
