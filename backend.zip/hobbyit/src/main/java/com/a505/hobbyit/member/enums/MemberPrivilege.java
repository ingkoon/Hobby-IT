package com.a505.hobbyit.member.enums;

public enum MemberPrivilege {
    ADMIN, GENERAL
}
