package com.a505.hobbyit.hobbymember.enums;

public enum HobbyMemberPrivilege {
    OWNER, MANAGER, GENERAL
}
