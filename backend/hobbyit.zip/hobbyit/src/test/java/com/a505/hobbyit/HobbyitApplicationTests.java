package com.a505.hobbyit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HobbyitApplicationTests {

	@Test
	void contextLoads() {
	}

}
